#' multiseq
#'
#' @name multiseq
#' @docType package
NULL
