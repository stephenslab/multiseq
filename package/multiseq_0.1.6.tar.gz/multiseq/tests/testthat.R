library(testthat)
library(multiseq)

test_check("multiseq")
