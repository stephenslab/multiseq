
################################## GENERIC FUNCTIONS ############################
#' compdens
#' @export
# find matrix of densities at y, for each component of the mixture
# INPUT y is an n-vector
# OUTPUT k by n matrix of densities
compdens = function(x,y,log=FALSE){
  UseMethod("compdens")
}

#' compdens.default
#' @export
compdens.default = function(x,y,log=FALSE){
  stop("No such class")
}

#' comp_sd
#' @export
#standard deviations
comp_sd = function(m){
  UseMethod("comp_sd")
}

#' comp_sd.default
#' @export
comp_sd.default = function(m){
  stop("method comp_sd not written for this class")
}

#' comp_mean2
#' @export
#second moments
comp_mean2 = function(m){
  UseMethod("comp_mean2")
}

#' comp_mean2.default
#' @export
comp_mean2.default = function(m){
  comp_sd(m)^2 + comp_mean(m)^2
}

#' mixmean
#' @export 
#return the overall mean of the mixture
mixmean = function(m){
  UseMethod("mixmean")
}

#' mixmean.default
#' @export
mixmean.default = function(m){
  sum(m$pi * comp_mean(m))
}

#' mixmean2
#' @export
#return the overall second moment of the mixture
mixmean2 = function(m){
  UseMethod("mixmean2")
}

#' mixmean2.default
#' @export
mixmean2.default = function(m){
  sum(m$pi * comp_mean2(m))
}

#' mixsd
#' @export
#return the overall sd of the mixture
mixsd = function(m){
  UseMethod("mixsd")
}

#' mixsd.default
#' #' @export
mixsd.default = function(m){
  sqrt(mixmean2(m)-mixmean(m)^2)
}

#' comp_mean
#' @export
#means
comp_mean = function(m){
  UseMethod("comp_mean")
}

#' comp_mean.default
#' #' @export
comp_mean.default = function(m){
  stop("method comp_mean not written for this class")
}

#' ncomp
#' @export
#number of components
ncomp = function(m){
  UseMethod("ncomp")
}

#' ncomp.defaul
#' @export
ncomp.default = function(m){
  return(length(m$pi))
}

#' mixprop
#' @export
#return mixture proportions, a generic function
mixprop = function(m){
  UseMethod("mixprop")
}

#' mixprop.default
#' @export
mixprop.default = function(m){
  m$pi
}

#' @title mixcdf
#'
#' @description Returns cdf for a mixture (generic function)
#' 
#' @details None
#' 
#' @param x a mixture (eg of type normalmix or unimix)
#' @param y locations at which cdf to be computed
#' @param lower.tail: boolean indicating whether to report lower tail
#' 
#' @return an object of class normalmix
#' 
#' @export
#' 
#' @examples mixcdf(normalmix(c(0.5,0.5),c(0,0),c(1,2)),seq(-4,4,length=100))
#' 
mixcdf = function(x,y,lower.tail=TRUE){
  UseMethod("mixcdf")
}
#' @title mixcdf.default
#' @export
#' 
mixcdf.default = function(x,y,lower.tail=TRUE){
  x$pi %*% comp_cdf(x,y,lower.tail)
}

#' comp_cdf
#' @export
#find cdf for each component, a generic function
comp_cdf = function(x,y,lower.tail=TRUE){
  UseMethod("comp_cdf")
}

#' comp_cdf.default
#' @export
comp_cdf.default = function(x,y,lower.tail=TRUE){
  stop("comp_cdf not implemented for this class")
}

#' dens
#' @export
#find density at y, a generic function
dens = function(x,y){
  UseMethod("dens")
}

#' dens.default
#' @export
dens.default = function(x,y){
  return (x$pi %*% compdens(x, y))
}

#' loglik
#' #' @export
#find log likelihood of data in x (a vector) for mixture in m
loglik = function(m,x){
  UseMethod("loglik")
}

#' loglik.default
#' @export
loglik.default = function(m,x){
  sum(log(dens(m,x)))
}

#find log likelihood of data in betahat, when 
#the mixture m is convolved with a normal with sd betahatsd
#betahatsd is an n vector
#betahat is an n vector
#' @title loglik_conv
#' 
#' @export
#' 
loglik_conv = function(m,betahat,betahatsd,FUN="+"){
  UseMethod("loglik_conv")
}
#' @title loglik_conv.default
#' 
#' @export
#' 
loglik_conv.default = function(m,betahat,betahatsd,FUN="+"){
  sum(log(dens_conv(m,betahat,betahatsd,FUN)))
}

#' compdens_conv
#' @export
#compute the density of the components of the mixture m
#when convoluted with a normal with standard deviation s
#the density is evaluated at x
#x and s are n-vectors
#m is a mixture with k components
#output is a k by n matrix of densities
compdens_conv = function(m, x, s, FUN="+"){
  UseMethod("compdens_conv")
}

#' compdens_conv.default
#' @export
compdens_conv.default = function(m,x, s,FUN="+"){
  stop("No such class")
}

#' dens_conv
#' @export
#compute density of mixture m convoluted with normal of sd (s)
#at locations x
#m is a mixture
#x is an n vector
#s is an n vector or integer
dens_conv = function(m,x,s,FUN="+"){
  UseMethod("dens_conv")
}

#' dens_conv.default
#' @export
dens_conv.default = function(m,x,s,FUN="+"){
  colSums(m$pi * compdens_conv(m,x,s,FUN))
}

#' comppostprob
#' @export
#compute the posterior prob that each observation
#came from each component of the mixture m
#output a k by n vector of probabilities
#computed by weighting the component densities by pi
#and then normalizing
comppostprob=function(m,x,s){
 UseMethod("comppostprob") 
}

#' comppostprob.defaul
#' @export
comppostprob.default = function(m,x,s){
  tmp= (t(m$pi * compdens_conv(m,x,s))/dens_conv(m,x,s))
  ismissing = (is.na(x) | is.na(s))
  tmp[ismissing,]=m$pi
  t(tmp)
}

#' compcdf_post
#' @export
# evaluate cdf of posterior distribution of beta at c
# m is the prior on beta, a mixture
# c is location of evaluation
# assumption is betahat | beta \sim N(beta,sebetahat)
# m is a mixture with k components
# c a scalar
# betahat, sebetahat are n vectors 
# output is a k by n matrix
compcdf_post=function(m,c,betahat,sebetahat){
  UseMethod("compcdf_post")
}

#' compcdf_post.default
#' @export
compcdf_post.default=function(m,c,betahat,sebetahat){
  stop("method compcdf_post not written for this class")
}

#' cdf_post
#' @export
cdf_post = function(m,c,betahat,sebetahat){
  UseMethod("cdf_post")
}

#' cdf_post.default
#' @export
cdf_post.default=function(m,c,betahat,sebetahat){
  colSums(comppostprob(m,betahat,sebetahat)*compcdf_post(m,c,betahat,sebetahat))
}

#' postmean
#' @export
#output posterior mean for beta for prior mixture m,
#given observations betahat, sebetahat
postmean = function(m, betahat,sebetahat){
  UseMethod("postmean")
}

#' postmean.default
#' @export
postmean.default = function(m,betahat,sebetahat){
  colSums(comppostprob(m,betahat,sebetahat) * comp_postmean(m,betahat,sebetahat))
}

#' postmean
#' @export
#output posterior mean-squared value for beta for prior mixture m,
#given observations betahat, sebetahat
postmean2 = function(m, betahat,sebetahat){
  UseMethod("postmean2")
}

#' postmean2.default
#' @export
postmean2.default = function(m,betahat,sebetahat){
  colSums(comppostprob(m,betahat,sebetahat) * comp_postmean2(m,betahat,sebetahat))
}

#' postsd
#' @export
#output posterior sd for beta for prior mixture m,
#given observations betahat, sebetahat
postsd = function(m, betahat,sebetahat){
  UseMethod("postsd")
}

#' postsd.default
#' @export
postsd.default = function(m,betahat,sebetahat){
  sqrt(postmean2(m,betahat,sebetahat)-postmean(m,betahat,sebetahat)^2)
}

#' comp_postmean2
#' @export
#output posterior mean-squared value for beta for prior mixture m,
#given observations betahat, sebetahat
comp_postmean2 = function(m, betahat,sebetahat){
  UseMethod("comp_postmean2")
}

#' comp_postmean2.default
#' @export
comp_postmean2.default = function(m,betahat,sebetahat){
  comp_postsd(m,betahat,sebetahat)^2 + comp_postmean(m,betahat,sebetahat)^2
}

#' comp_postmean
#' @export
#output posterior mean for beta for each component of prior mixture m,
#given observations betahat, sebetahat
comp_postmean = function(m, betahat,sebetahat){
  UseMethod("comp_postmean")
}

#' comp_postmean.default
#' @export
comp_postmean.default = function(m,betahat,sebetahat){
  stop("method comp_postmean not written for this class")
}

#' comp_postsd
#' @export
#output posterior sd for beta for each component of prior mixture m,
#given observations betahat, sebetahat
comp_postsd = function(m, betahat,sebetahat){
  UseMethod("comp_postsd")
}

#' comp_postsd.default
#' @export
comp_postsd.default = function(m,betahat,sebetahat){
  stop("method comp_postsd not written for this class")
}

#' min_lim
#' @export
#find nice limits of mixture m for plotting
min_lim = function(m){
  UseMethod("min_lim")
}

#' min_lim.default
#' @export
min_lim.default=function(m){
  -5
}

#' max_lim
#' @export
max_lim = function(m){
  UseMethod("max_lim")
}
max_lim.default=function(m){
  5
}

#' plot_dens
#' @export
#plot density of mixture
plot_dens = function(m,npoints=100,...){
  UseMethod("plot_dens")
}

#' plot_dens.default
#' @export
plot_dens.default = function(m,npoints=100,...){
  x = seq(min_lim(m),max_lim(m),length=npoints)
  plot(x,dens(m,x),type="l",xlab="density",ylab="x",...)
}

#' plot_post_cdf
#' @export
plot_post_cdf = function(m,betahat,sebetahat,npoints=100,...){
  UseMethod("plot_post_cdf")
}

#' plot_post_cdf.default
#' @export
plot_post_cdf.default = function(m,betahat,sebetahat,npoints=100,...){
  x = seq(min_lim(m),max_lim(m),length=npoints)
  x_cdf = vapply(x,cdf_post,FUN.VALUE=betahat,m=m,betahat=betahat,sebetahat=sebetahat)
  plot(x,x_cdf,type="l",xlab="x",ylab="cdf",...)
 # for(i in 2:nrow(x_cdf)){
 #   lines(x,x_cdf[i,],col=i)
 # }
}

############################### METHODS FOR normalmix class ###########################

#' @title Constructor for normalmix class
#'
#' @description Creates an object of class normalmix (finite mixture of univariate normals)
#' 
#' @details None
#' 
#' @param pi vector of mixture proportions
#' @param mean vector of means
#' @param sd: vector of standard deviations
#' 
#' @return an object of class normalmix
#' 
#' @export
#' 
#' @examples normalmix(c(0.5,0.5),c(0,0),c(1,2))
#' 
normalmix = function(pi,mean,sd){
  structure(data.frame(pi,mean,sd),class="normalmix")
}

#' comp_sd.normalmix
#' @export
comp_sd.normalmix = function(m){
  m$sd
}

#' comp_mean.normalmix
#' @export
comp_mean.normalmix = function(m){
  m$mean
}

#' compdens.normalmix
#' @export
compdens.normalmix = function(x,y,log=FALSE){
  k=ncomp(x)
  n=length(y)
  d = matrix(rep(y,rep(k,n)),nrow=k)
  return(matrix(dnorm(d, x$mean, x$sd, log),nrow=k))  
}

#' compdens_conv.normalmix
#' @export
#density of convolution of each component of a normal mixture with N(0,s^2) at x
# x an n-vector at which density is to be evaluated
#return a k by n matrix
#Note that convolution of two normals is normal, so it works that way
compdens_conv.normalmix = function(m, x, s,FUN="+"){
  if(length(s)==1){s=rep(s,length(x))}
  sdmat = sqrt(outer(s^2,m$sd^2,FUN)) #n by k matrix of standard deviations of convolutions
  return(t(dnorm(outer(x,m$mean,FUN="-")/sdmat)/sdmat))
}

#' comp_cdf.normalmix
#' @export
comp_cdf.normalmix = function(x,y,lower.tail=TRUE){
  vapply(y,pnorm,x$mean,x$mean,x$sd,lower.tail)
}

#' compcdf_post.normalmix
#' @export
#c is a scalar
#m a mixture with k components
#betahat a vector of n observations
#sebetahat an n vector of standard errors
#return a k by n matrix of the posterior cdf
compcdf_post.normalmix=function(m,c,betahat,sebetahat){
  k = length(m$pi)
  n=length(betahat)
  #compute posterior standard deviation (s1) and posterior mean (m1)
  s1 = sqrt(outer(sebetahat^2,m$sd^2,FUN="*")/outer(sebetahat^2,m$sd^2,FUN="+"))
  ismissing = (is.na(betahat) | is.na(sebetahat))
  s1[ismissing,]=m$sd
  
  m1 = t(comp_postmean(m,betahat,sebetahat))
  t(pnorm(c,mean=m1,sd=s1))
}

#' comp_postmean.normalmix
#' @export
#return posterior mean for each component of prior m, given observations betahat and sebetahat
#input, m is a mixture with k components
#betahat, sebetahat are n vectors
#output is a k by n matrix
comp_postmean.normalmix = function(m,betahat,sebetahat){
  tmp=(outer(sebetahat^2,m$mean, FUN="*") + outer(betahat,m$sd^2, FUN="*"))/outer(sebetahat^2,m$sd^2,FUN="+")
  ismissing = (is.na(betahat) | is.na(sebetahat))
  tmp[ismissing,]=m$mean #return prior mean when missing data
  t(tmp)
}

#' comp_postsd.normalmix
#' @export
#return posterior mean for each component of prior m, given observations betahat and sebetahat
#input, m is a mixture with k components
#betahat, sebetahat are n vectors
#output is a k by n matrix
comp_postsd.normalmix = function(m,betahat,sebetahat){
  t(sqrt(outer(sebetahat^2,m$sd^2,FUN="*")/outer(sebetahat^2,m$sd^2,FUN="+")))
}


############################### METHODS FOR unimix class ###########################

#' unimix
#' @export
#constructor; pi, a and b are vectors; kth component is Uniform(a[k],b[k])
unimix = function(pi,a,b){
  structure(data.frame(pi,a,b),class="unimix")
}

#' comp_cdf.unimix
#' @export
comp_cdf.unimix = function(m,y,lower.tail=TRUE){
  vapply(y,punif,m$a,min=m$a,max=m$b,lower.tail)
}

#' comp_sd.unimix
#' @export
comp_sd.unimix = function(m){
  (m$b-m$a)/sqrt(12)
}

#' comp_mean.unimix
#' @export
comp_mean.unimix = function(m){
  (m$a+m$b)/2
}


#' compdens.unimix
#' @export
compdens.unimix = function(x,y,log=FALSE){
  k=ncomp(x)
  n=length(y)
  d = matrix(rep(y,rep(k,n)),nrow=k)
  return(matrix(dunif(d, x$a, x$b, log),nrow=k))  
}

#' compdens_conv.unimix
#' @export
#density of convolution of each component of a unif mixture with N(0,s) at x
# x an n-vector
#return a k by n matrix
compdens_conv.unimix = function(m, x, s, FUN="+"){
  if(FUN!="+") stop("Error; compdens_conv not implemented for uniform with FUN!=+")
  return(t(pnorm(outer(x,m$a,FUN="-")/s)
          -pnorm(outer(x,m$b,FUN="-")/s))/(m$b-m$a))
}

#' compcdf_post.unimix
#' @export
#c is a scalar
#m a mixture with k components
#betahat a vector of n observations
#sebetahat an n vector of standard errors
#return a k by n matrix of the posterior cdf
compcdf_post.unimix=function(m,c,betahat,sebetahat){
  k = length(m$pi)
  n=length(betahat)
  tmp = matrix(1,nrow=k,ncol=n)
  tmp[m$a >= c,] = 0
  subset = m$a<c & m$b>c # subset of components (1..k) with nontrivial cdf
  if(sum(subset)>0){
    pna = pnorm(outer(betahat,m$a[subset],FUN="-")/sebetahat)
    pnc = pnorm(outer(betahat,rep(c,sum(subset)),FUN="-")/sebetahat)
    pnb = pnorm(outer(betahat,m$b[subset],FUN="-")/sebetahat)
    tmp[subset,] = t((pnc-pna)/(pnb-pna))
  }
  tmp
}

#' my_etruncnorm
#' @export
my_etruncnorm= function(a,b,mean=0,sd=1){
  alpha = (a-mean)/sd
  beta =  (b-mean)/sd
 #Flip the onese where both are positive, as the computations are more stable
  #when both negative
  flip = (alpha>0 & beta>0)
  flip[is.na(flip)]=FALSE #deal with NAs
  alpha[flip]= -alpha[flip]
  beta[flip]=-beta[flip]
  
  tmp= (-1)^flip * (mean+sd*etruncnorm(alpha,beta,0,1))
  
  max_alphabeta = ifelse(alpha<beta, beta,alpha)
  max_ab = ifelse(alpha<beta,b,a)
  toobig = max_alphabeta<(-30)
  toobig[is.na(toobig)]=FALSE 
  tmp[toobig] = max_ab[toobig]
  tmp
}
  
#' comp_postmean.unimix
#' @export
#return posterior mean for each component of prior m, given observations betahat and sebetahat
#input, m is a mixture with k components
#betahat, sebetahat are n vectors
#output is a k by n matrix
#note that with uniform prior, posterior is truncated normal, so
#this is computed using formula for mean of truncated normal 
comp_postmean.unimix = function(m,betahat,sebetahat){
#   k= ncomp(m)
#   n=length(betahat)
#   a = matrix(m$a,nrow=n,ncol=k,byrow=TRUE)
#   b = matrix(m$b,nrow=n,ncol=k,byrow=TRUE)
#   matrix(etruncnorm(a,b,betahat,sebetahat),nrow=k,byrow=TRUE)
  #note: etruncnorm is more stable for a and b negative than positive
  #so maybe use this, and standardize to make the whole more stable.
  
  alpha = outer(-betahat, m$a,FUN="+")/sebetahat
  beta = outer(-betahat, m$b, FUN="+")/sebetahat
  tmp = betahat + sebetahat*my_etruncnorm(alpha,beta,0,1)
  ismissing = is.na(betahat) | is.na(sebetahat)
  tmp[ismissing,]= (m$a+m$b)/2
  t(tmp)
#   t(
#     betahat + sebetahat* 
#       exp(dnorm(alpha,log=TRUE)- pnorm(alpha,log=TRUE))
#    * 
#       (-expm1(dnorm(beta,log=TRUE)-dnorm(alpha,log=TRUE)))
#     /
#       (expm1(pnorm(beta,log=TRUE)-pnorm(alpha,log=TRUE)))
#   )
}

#' comp_postsd.unimix
#' @export
#not yet implemented!
#just returns 0s for now
comp_postsd.unimix = function(m,betahat,sebetahat){
  print("Warning: Posterior SDs not yet implemented for uniform components")
  k= ncomp(m)
  n=length(betahat)
  return(matrix(NA,nrow=k,ncol=n)) 
}

